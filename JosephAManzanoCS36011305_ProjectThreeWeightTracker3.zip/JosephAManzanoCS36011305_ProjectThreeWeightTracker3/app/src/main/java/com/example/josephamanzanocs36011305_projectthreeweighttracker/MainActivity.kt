package com.example.josephamanzanocs36011305_projectthreeweighttracker

import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity() : AppCompatActivity(), Parcelable {
    constructor(parcel: Parcel) : this() {
    }

/* While I was unable to get the application to run. I attempted to write the code with best practices to demonstrate
 an understanding of the material. The UI design shows the simplicity of the application while the attempts to navigate through the
 UI are shown in classes.
 */



    public class EmailDAO {

        private DBHelper dbHelper;
        private SQLiteDatabase database;

        public EmailDAO(Context context) {
            dbHelper = new DBHelper(context);
        }


        public void open() {
            database = dbHelper.getWritableDatabase();
        }


        public void close() {
            dbHelper.close();
        }

        // Input a new account email and password
        public long insertUser(String email, String password) {
            ContentValues values = new ContentValues();
            values.put(DBHelper.COLUMN_EMAIL, email);
            values.put(DBHelper.COLUMN_PASSWORD, password);

            return database.insert(DBHelper.TABLE_NAME, null, values);
        }

        // Check for Email account
        public User getUserByEmail(String email) {
            String[] projection = {
                DBHelper.COLUMN_ID,
                DBHelper.COLUMN_EMAIL,
                DBHelper.COLUMN_PASSWORD
            };

            String selection = DBHelper.COLUMN_Email + " ...";
            String[] selectionArgs = { email };

            Cursor cursor = database.query(
                    DBHelper.TABLE_NAME,
            projection,
            selection,
            selectionArgs,
            null,
            null,
            null
            );

            Email email = null;
            if (cursor != null && cursor.moveToFirst()) {
                long id = cursor.getLong(cursor.getColumnIndex(DBHelper.COLUMN_ID));
                String storedEmail = cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_Email));
                String storedPassword = cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_PASSWORD));
                email = new Email(id, storedEmail, storedPassword);
                cursor.close();
            }

            return user;
        }

        // Inner class representing a User
        public static class User {
            private long id;
            private String email;
            private String password;

            public User(long id, String email, String password) {
                this.id = id;
                this.email = email;
                this.password = password;
            }

            public long getId() {
                return id;
            }

            public String getEmail() {
                return email;
            }

            public String getPassword() {
                return password;
            }
        }




    public class MainActivity extends AppCompatActivity {


        private static final String CORRECT_EMAIL = "Checking";
        private static final String CORRECT_PASSWORD = "password";

        private EditText editTextEmail;
        private EditText editTextPassword;
        private Button buttonLogin;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            editTextEmail = findViewById(R.id.editTextEmail);
            editTextPassword = findViewById(R.id.editTextPassword);
            buttonLogin = findViewById(R.id.buttonLogin);

            buttonLogin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String email = editTextEmail.getText().toString();
                    String password = editTextPassword.getText().toString();

                    if (username.equals(CORRECT_EMAIL) && password.equals(CORRECT_PASSWORD)) {
                        // Successful login
                        Toast.makeText(MainActivity.this, "Logging In", Toast.LENGTH_SHORT).show();
                        // Continue
                    } else {
                        // Incorrect Email or Password
                        Toast.makeText(MainActivity.this, "Incorrect Email or Password", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            public class DBHelper extends SQLiteOpenHelper {

            // Info
            private static final int DATABASE_VERSION = 1;
            private static final String DATABASE_NAME = "Email.db";

            // Table name and column name
            private static final String TABLE_NAME = "emails";
            private static final String COLUMN_ID = "id";
            private static final String COLUMN_EMAIL = "email";
            private static final String COLUMN_PASSWORD = "password";

            // Create table
            private static final String SQL_CREATE_ENTRIES =
                "CREATE TABLE " + TABLE_NAME + " (" +
                        COLUMN_ID + " INTEGER ," +
                        COLUMN_EMAIL + " TEXT," +
                        COLUMN_PASSWORD + " TEXt)";


            public DBHelper(Context context) {
                super(context, DATABASE_NAME, null, DATABASE_VERSION);
            }

            @Override
            public void onCreate(SQLiteDatabase db) {
                db.execSQL(SQL_CREATE_ENTRIES);
            }

            @Override
            public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {

    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<MainActivity> {
        override fun createFromParcel(parcel: Parcel): MainActivity {
            return MainActivity(parcel)
        }

        override fun newArray(size: Int): Array<MainActivity?> {
            return arrayOfNulls(size)
        }
    }
            private EmailDAO emailDAO;

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);


                emailDAO = new EmailDAO(this);


                emailDAO.open();


                long emailId = userDAO.insertemail("testemail", "testpassword");
                if (emailId != -1) {
                    Toast.makeText(this, "email inserted with ID: " + emailId, Toast.LENGTH_SHORT).show();
                }

                EmailDAO.Email email = emailDAO.getEmailByEmail("Email");
                if (email != null) {
                    Toast.makeText(this, "Email found: " + email.getUsername() + ", Password: " + email.getPassword(), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Email not found", Toast.LENGTH_SHORT).show();
                }

                // Close the database connection
                emailDAO.close();
            }
            public class MainActivity extends AppCompatActivity {

            private static final int PERMISSION_REQUEST_SEND_SMS = 1;

            private Button buttonSendSMS;

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

                buttonSendSMS = findViewById(R.id.buttonSendSMS);

                buttonSendSMS.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS)
                            != PackageManager.PERMISSION_GRANTED) {

                            ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SEND_SMS);
                        } else {

                            sendSMS();
                        }
                    }
                });
            }

            @Override
            public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
                if (requestCode == PERMISSION_REQUEST_SEND_SMS) {
                    if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        // Permission granted, send SMS
                        sendSMS();
                    } else {
                        // Permission denied
                        Toast.makeText(MainActivity.this, "No Permission", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            private void sendSMS() {
                String phoneNumber = "1-800-588-2300";
                String message = "Time to Weigh in!";

                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                    Toast.makeText(getApplicationContext(), "Message Sent.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Message Failed.", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }

}